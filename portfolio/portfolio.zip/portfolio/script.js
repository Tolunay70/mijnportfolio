 function verzonden () {
    alert("Bericht succesvol verzonden!")
}